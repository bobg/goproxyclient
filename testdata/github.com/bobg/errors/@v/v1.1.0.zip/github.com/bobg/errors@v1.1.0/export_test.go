package errors

// Make the wrapped type visible to the test package.
type Wrapped = wrapped
